package com.example.myget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
