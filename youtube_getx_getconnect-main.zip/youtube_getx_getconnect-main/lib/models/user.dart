class User {
  String id;
  String? name;
  String? email;
  String? phone;

  User({required this.id, this.name, this.email, this.phone});
}
