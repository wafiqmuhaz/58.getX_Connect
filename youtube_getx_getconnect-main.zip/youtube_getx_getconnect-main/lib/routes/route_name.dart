abstract class RouteName {
  static const home = "/";
  static const add = "/add";
  static const profile = "/profile";
}
